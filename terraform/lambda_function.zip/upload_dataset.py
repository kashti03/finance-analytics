import boto3
import csv
import os

dynamodb = boto3.resource('dynamodb', region_name='us-west-2')

def upload_csv_to_dynamodb(file_path, table_name):
    table = dynamodb.Table(table_name)
    with open(file_path, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            table.put_item(Item=row)
    print(f"Uploaded {file_path} to {table_name}")

if __name__ == "__main__":
    base_path = os.path.join(os.path.dirname(__file__), '..', 'data')
    env = os.environ.get("ENV", "dev")  # fallback to dev

    datasets = {
        f"{env}_finance_data": "finance_data.csv",
        f"{env}_order_report_data": "order_report_data.csv",
        f"{env}_product_report_data": "product_report_data.csv"
    }

    for table_name, file in datasets.items():
        path = os.path.join(base_path, file)
        upload_csv_to_dynamodb(path, table_name)
